function saveEntry() {
    const mood = document.getElementById("mood").value;
    const entryText = document.getElementById("entry").value.trim();

    if (entryText === "") {
        alert("Please write something in your journal entry!");
        return;
    }

    const entriesDiv = document.getElementById("entries");

    const newEntry = document.createElement("div");
    newEntry.classList.add("entry");

    const today = new Date();
    const date = today.toLocaleDateString();
    const time = today.toLocaleTimeString();

    newEntry.innerHTML = `
        <strong>Date:</strong> ${date} <br>
        <strong>Time:</strong> ${time} <br>
        <strong>Mood:</strong> ${mood} <br>
        <strong>Entry:</strong> ${entryText}
    `;

    entriesDiv.prepend(newEntry); // New entries come on top

    // Clear the textarea
    document.getElementById("entry").value = "";
}
